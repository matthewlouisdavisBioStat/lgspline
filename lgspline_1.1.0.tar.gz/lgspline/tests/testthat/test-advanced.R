test_that("Weibull accelerated failure time (AFT) models can be fit under custom constraints", {
  ## Setup
  set.seed(1234)
  t1 <- rnorm(1000)
  t2 <- rbinom(1000, 1, 0.5)
  yraw <- rexp(exp(0.01*t1 + 0.01*t2))
  status <- rbinom(1000, 1, 0.25)
  yobs <- ifelse(status, runif(1, 0, yraw), yraw)
  df <- data.frame(
    y = yobs,
    t1 = t1,
    t2 = t2
  )
  ## Weibull AFT
  model_fit_aft <- lgspline(
    y ~ spl(t1) + t2,
    df,
    unconstrained_fit_fxn = unconstrained_fit_weibull,
    family = weibull_family(),
    need_dispersion_for_estimation = TRUE,
    qp_score_function = weibull_qp_score_function,
    dispersion_function = weibull_dispersion_function,
    glm_weight_function = weibull_glm_weight_function,
    schur_correction_function = weibull_schur_correction,
    K = 1,
    include_constrain_fitted = FALSE,
    flat_ridge_penalty = 1e-2,
    wiggle_penalty = 1e-2,
    unique_penalty_per_predictor = FALSE,
    unique_penalty_per_partition = FALSE,
    opt = FALSE,
    return_varcovmat = TRUE,
    observation_weights = 0.5 + 0.5 * abs(rnorm(1000)),
    constraint_vectors = cbind(rep(1, 12)),
    null_constraint = matrix(12),
    status = status,
    verbose = TRUE,
    verbose_tune = TRUE
  )
  print(model_fit_aft)
  ## Check sum-to-P constraint only if model_fit_aft is a list
  if (is.list(model_fit_aft)) {
    expect_equal(round(sum(unlist(model_fit_aft$B)), 8), 12)
  } else {
    ## Skip the test on platforms when model returns a try-error instead
    expect_error(invisible(), NA)
  }
})


test_that("Weibull family log-likelihood uses fitted observation weights", {
  log_y <- log(c(1.2, 2.4, 3.6))
  log_mu <- log(c(1.1, 2.2, 3.1))
  status <- c(1, 0, 1)
  weights <- c(1, 3, 5)

  model_fit <- list(
    y = exp(log_y),
    ytilde = exp(log_mu),
    sigmasq_tilde = 0.64,
    status = status,
    weights = weights
  )

  expect_equal(
    weibull_family()$loglik(model_fit),
    loglik_weibull(log_y, log_mu, status, sqrt(0.64), weights)
  )
})
